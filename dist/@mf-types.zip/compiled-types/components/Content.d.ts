import React from 'react';
import './Content.css';
declare const Provider: React.FC;
export default Provider;
